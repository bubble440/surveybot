"""
input_dropdown.py - Gestion des dropdowns et <select> pour input_handler

Ce module contient:
- Détection et ouverture de dropdowns (natifs et custom)
- Sélection d'options dans dropdowns
- Vérification de l'état (rempli/vide)
- Support: <select>, Angular Material, MUI, Select2, jQuery UI, ARIA

Dépendances:
- input_utils pour les fonctions de normalisation et constantes
"""






import time
import re

# Import depuis input_utils
from Survey.input_utils import (
    norm_txt,
    norm_text,
    DROPDOWN_PLACEHOLDERS,
    PLACEHOLDER_TOKENS,
    similarity,
)
from Survey.log_utils import log_debug


# =============================================================================
# HELPERS DE DÉTECTION DROPDOWN
# =============================================================================

def has_native_selects(driver) -> bool:
    """Vérifie si la page contient des <select> natifs."""
    return bool(driver.query_selector_all("select"))


def select_like_elements(driver):
    """
    Retourne tous les éléments qui ressemblent à des dropdowns.
    Inclut: <select>, role=combobox, aria-haspopup=listbox, .select classes.
    """
    els = []
    els += driver.query_selector_all("select")
    els += driver.query_selector_all("[role='combobox'], [aria-haspopup='listbox']")
    # togglers fréquents (custom selects)
    els += driver.query_selector_all(
        "xpath=//*[contains(@class,'select') and (self::div or self::button or self::span)]"
    )
    return [e for e in els if e is not None]


def element_signature_text(driver, el) -> str:
    """
    Concatène tout ce qui décrit un champ dropdown (labels/aria/placeholder).
    Utilisé pour matcher le bon dropdown avec un hint.
    """
    bits = []
    try:
        # label for=…
        eid = el.get_attribute("id")
        if eid:
            lbl = driver.query_selector(f"label[for='{eid}']")
            if lbl:
                t = (lbl.inner_text() or "").strip()
                if t:
                    bits.append(t)
        # aria-label / labelledby
        a = (el.get_attribute("aria-label") or "").strip()
        if a:
            bits.append(a)
        labby = (el.get_attribute("aria-labelledby") or "").strip()
        if labby:
            for ref in labby.split():
                n = driver.query_selector(f"#{ref}")
                if n:
                    t = (n.inner_text() or n.get_attribute("innerText") or "").strip()
                    if t:
                        bits.append(t)
        # placeholder
        ph = (el.get_attribute("placeholder") or "").strip()
        if ph:
            bits.append(ph)
        # texte du conteneur question
        try:
            q = el.find_element(
                "xpath",
                "ancestor::*[contains(@class,'Question') or contains(@class,'question') or contains(@class,'body') or self::fieldset][1]",
            )
            t = (q.text or "").strip()
            if t:
                bits.append(t)
        except Exception:
            pass
    except Exception:
        pass
    sig = " ".join(bits)
    return norm_txt(sig)


def viewport_penalty(driver, el) -> float:
    """
    Pénalise les éléments dans le header/footer (sélecteur de langue, navbar...).
    Retourne un score négatif pour ces zones.
    """
    try:
        r = el.bounding_box() or {}
        y = r.get("y", 0)
        htot = (
            driver.evaluate(
                "() => Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, window.innerHeight)"
            )
            or 2000
        )
        # pénalise header/footer
        if y < 120:
            return -0.75
        if y > htot - 220:
            return -0.5
    except Exception:
        pass
    return 0.0


def best_dropdown_for_hint(driver, hint: str | None, context_hint: str | None = None):
    """
    Trouve le dropdown le plus pertinent selon le hint fourni.
    
    Args:
        driver: WebDriver
        hint: hint de recherche (ex: "année", "mois", "pays")
        context_hint: contexte de question optionnel
    
    Returns:
        WebElement du dropdown le plus pertinent, ou None
    """
    cands = select_like_elements(driver)
    if not cands:
        return None
    if not hint:
        return cands[0]
    
    h = norm_txt(hint)
    c = norm_txt(context_hint) if context_hint else ""
    
    # Disambiguation spécifique année/mois
    want = None
    if any(k in h for k in ("année", "annee", "year", "years")):
        want = "year"
    elif any(k in h for k in ("mois", "month", "months")):
        want = "month"

    best, best_score = None, -1e9
    for el in cands:
        try:
            sig = element_signature_text(driver, el)
            sim = similarity(h, sig)
            if want:
                try:
                    nid = norm_txt(((el.get_attribute("name") or "") + " " + (el.get_attribute("id") or "") + " " + (el.get_attribute("aria-label") or "")).strip())
                except Exception:
                    nid = ""
                try:
                    self_txt = norm_txt((el.text or el.get_attribute("innerText") or "").strip())
                except Exception:
                    self_txt = ""
                pool = f"{nid} {self_txt}"
                if want == "year":
                    if any(t in pool for t in ("année", "annee", "year", "years")):
                        sim += 0.55
                    else:
                        sim -= 0.25
                else:
                    if any(t in pool for t in ("mois", "month", "months")):
                        sim += 0.55
                    else:
                        sim -= 0.25

            # boost si le hint ressemble à des champs typiques
            if any(k in h for k in ("an", "année", "year", "mois", "month", "pays", "country", "ville", "city", "state", "province")):
                if any(k in sig for k in ("an", "année", "year", "mois", "month", "pays", "country", "ville", "city", "state", "province")):
                    if c:
                        sim += 0.35 * similarity(c, sig)
            
            score = sim + viewport_penalty(driver, el)
            if score > best_score:
                best, best_score = el, score
        except Exception:
            continue
    return best


# =============================================================================
# LECTURE DE VALEUR DROPDOWN
# =============================================================================

def dropdown_visible_value(driver, ctrl) -> str:
    """
    Lit le texte AFFICHÉ par le composant dropdown (pas l'input caché).
    Gère: <select>, Angular Material, MUI, Select2, jQuery UI.
    
    Returns:
        Texte affiché, ou "" si rien de fiable
    """
    # 1) <select> natif
    try:
        if ctrl.tag_name.lower() == "select":
            try:
                _sel_el = ctrl  # Playwright: use .select_option() and .evaluate() for options
                if sel.first_selected_option:
                    return sel.first_selected_option.text or ""
            except Exception:
                val = ctrl.get_attribute("value") or ""
                if val:
                    try:
                        opt = ctrl.find_element("xpath", f".//option[@value={repr(val)}]")
                        return opt["text"] or val
                    except Exception:
                        return val
    except Exception:
        pass

    # 2) MatSelect (Angular Material)
    for xp in [
        ".//div[contains(@class,'mat-select-value')]/span[contains(@class,'mat-select-value-text')]",
        ".//span[contains(@class,'mat-select-value-text')]",
    ]:
        try:
            el = ctrl.find_element("xpath", xp)
            txt = (el.text or el.get_attribute("innerText") or "").strip()
            if txt:
                return txt
        except Exception:
            pass

    # 3) MUI (Material-UI)
    for xp in [
        ".//*[contains(@class,'MuiSelect-select') and not(contains(@class,'MuiSelect-nativeInput'))]",
        ".//*[contains(@class,'MuiSelect-select') and @role='button']",
    ]:
        try:
            el = ctrl.find_element("xpath", xp)
            txt = (el.text or el.get_attribute("innerText") or "").strip()
            if txt:
                return txt
        except Exception:
            pass

    # 4) Select2
    for xp in [".//span[contains(@class,'select2-selection__rendered')]"]:
        try:
            el = ctrl.find_element("xpath", xp)
            txt = (el.get_attribute("title") or el.text or "").strip()
            if txt:
                return txt
        except Exception:
            pass

    # 5) jQuery UI / mobiles / ARIA button-like
    try:
        btn = ctrl
        if btn.get_attribute("role") != "button":
            btn = ctrl.find_element("xpath", ".//*[@role='button' or @aria-haspopup='listbox']")
        txt = (btn.text or btn.get_attribute("innerText") or "").strip()
        if txt:
            return txt
    except Exception:
        pass

    # 6) fallback: texte direct du contrôle
    try:
        txt = (ctrl.text or ctrl.get_attribute("innerText") or "").strip()
        return txt
    except Exception:
        return ""


def is_dropdown_filled(driver, ctrl) -> bool:
    """
    True si la valeur affichée semble une vraie valeur (≠ placeholder/vide).
    Gère <select> natif et la plupart des rendus UI.
    """
    # cas natif <select>
    try:
        if ctrl.tag_name.lower() == "select":
            val = ctrl.get_attribute("value") or ""
            if val and norm_txt(val) not in DROPDOWN_PLACEHOLDERS:
                return True
            try:
                _sel_el = ctrl  # Playwright: use .select_option() and .evaluate() for options
                txt = norm_txt(sel.first_selected_option.text or "")
                return bool(txt and txt not in DROPDOWN_PLACEHOLDERS)
            except Exception:
                return False
    except Exception:
        pass

    # texte rendu par le composant
    txt = norm_txt(dropdown_visible_value(driver, ctrl))
    if not txt:
        return False

    # placeholders les + fréquents
    if txt in DROPDOWN_PLACEHOLDERS:
        return False

    # phrases usuelles
    for bad in ("veuillez", "please", "select", "sélectionner", "selectionner", "choose"):
        if txt.startswith(bad):
            return False

    return True


# =============================================================================
# OUVERTURE DE DROPDOWN
# =============================================================================

def open_first_dropdown(driver) -> bool:
    """
    Ouvre un dropdown visible (natif <select> ou custom role=combobox / bouton).
    Ne sélectionne pas d'option ici ; juste « abaisser » le menu.
    """
    # 1) <select> natif
    selects = driver.query_selector_all("select")
    for s in selects:
        try:
            if s.is_visible():
                driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", s)
                time.sleep(0.1)
                s.click()
                print("🔒 Dropdown (natif) ouvert... source: input_dropdown.py")
                return True
        except Exception:
            continue

    # 2) Dropdowns customs
    togglers = []
    togglers += driver.query_selector_all("[role='combobox']")
    togglers += driver.query_selector_all("[aria-haspopup='listbox']")
    togglers += driver.query_selector_all(
        "xpath=//*[contains(@class,'select') and (self::div or self::button or self::span)]"
    )
    for t in togglers:
        try:
            _bb = t.bounding_box() or {}
            if t.is_visible() and _bb.get("width", 0) > 20 and _bb.get("height", 0) > 15:
                driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", t)
                time.sleep(0.1)
                try:
                    t.click()
                except Exception:
                    t.hover(); t.click()
                time.sleep(0.2)
                print("🔒 Dropdown (custom) ouvert. source: input_dropdown.py")
                return True
        except Exception:
            continue

    print("❌ Aucun dropdown à ouvrir. source: input_dropdown.py")
    return False


def open_dropdown_generic(driver, hint: str | None = None, context_hint: str | None = None) -> bool:
    """
    Ouvre le dropdown le plus pertinent selon le hint.
    Marque driver._ui_overlay_opened pour suivi.
    
    Args:
        driver: WebDriver
        hint: indice pour trouver le bon dropdown
        context_hint: contexte de question optionnel
    
    Returns:
        True si ouverture réussie
    """
    el = best_dropdown_for_hint(driver, hint, context_hint=context_hint)
    if not el:
        print("❌ Aucun dropdown à ouvrir. source: input_dropdown.py")
        return False
    
    # Les <select> natifs ne doivent pas être "ouverts" ici.
    # Leur sélection se fait directement dans select_option_with_hint().
    # Cliquer/focuser un select natif puis envoyer ARROW_DOWN peut modifier
    # une valeur déjà correcte avant la vraie sélection.
    if el.tag_name.lower() == "select":
        try:
            try:
                already_filled = is_dropdown_filled(driver, el)
            except Exception:
                already_filled = False

            driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", el)
            try:
                driver._ui_overlay_opened = {
                    "type": "dropdown",
                    "native": True,
                    "hint": hint or "",
                    "ts": time.time(),
                    "anchor": el,
                    "filled": already_filled
                }
                driver._last_dropdown_hint = hint or ""
            except Exception:
                pass
            print("ℹ️ Dropdown natif repéré sans ouverture; sélection directe attendue. source: input_dropdown.py")
            return True
        except Exception:
            print("⚠️ Select natif ciblé: ouverture impossible → on continuera par sélection directe. source: input_dropdown.py")
            return True

    try:
        try:
            already_filled = is_dropdown_filled(driver, el)
        except Exception:
            already_filled = False

        driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", el)
        try:
            el.click()
        except Exception:
            el.hover(); el.click()
        time.sleep(0.05)
        try:
            driver.keyboard.press("ArrowDown")
        except Exception:
            pass
        try:
            driver._ui_overlay_opened = {
                "type": "dropdown",
                "native": False,
                "hint": hint or "",
                "ts": time.time(),
                "anchor": el,
                "filled": already_filled
            }
            driver._last_dropdown_hint = hint or ""
        except Exception:
            pass
        print("🔒 Dropdown (custom) ouvert. source: input_dropdown.py")
        return True
    except Exception:
        print("❌ Échec à l'ouverture du dropdown ciblé. source: input_dropdown.py")
        return False


# =============================================================================
# SÉLECTION D'OPTIONS
# =============================================================================

def select_option_with_hint(driver, option_text: str, field_hint: str | None = None, context_hint: str | None = None) -> bool:
    """
    Tente de sélectionner 'option_text' si un <select> est présent
    ou si un menu custom est ouvert (ul/li, role=option...).
    
    Version basique sans hint de champ.
    """
    target = norm_txt(option_text)

    # Ne pas "sélectionner" un placeholder
    if target in {"mois", "année", "annee", "month", "year"}:
        print(f"⚠️ Valeur placeholder ignorée: '{option_text}'. source: input_dropdown.py")
        return False

    # A) <select> natif
    selects = driver.query_selector_all("select")
    for s in selects:
        try:
            # Sélection via JS (robuste même si <select> hidden / bootstrap-select)
            ok_js = False
            if target:
                try:
                    ok_js = bool(driver.execute_script(
                        """
                        const sel = arguments[0];
                        const target = arguments[1];
                        if (!sel || !driver.evaluate("el => Array.from(el.options).map(o => ({value:o.value,text:o.text.trim()}))", _sel_el)) return false;

                        const norm = (x) => (x || "").toString().trim().toLowerCase();
                        const tgt = norm(target);

                        let found = null;
                        for (const opt of driver.evaluate("el => Array.from(el.options).map(o => ({value:o.value,text:o.text.trim()}))", _sel_el)) {
                            const t = norm(opt.textContent);
                            if (!t) continue;
                            if (t === tgt || t.includes(tgt)) { found = opt; break; }
                        }
                        if (!found) return false;

                        sel.value = found.value;
                        found.selected = true;

                        try { sel.dispatchEvent(new Event('input', {bubbles:true})); } catch(e){}
                        try { sel.dispatchEvent(new Event('change',{bubbles:true})); } catch(e){}
                        try { sel.dispatchEvent(new Event('blur',  {bubbles:true})); } catch(e){}

                        try {
                          if (window.jQuery && window.jQuery(sel).selectpicker) {
                            window.jQuery(sel).selectpicker('refresh');
                          }
                        } catch(e){}

                        return true;
                        """,
                        s, target
                    ))
                except Exception:
                    ok_js = False

            if ok_js:
                print(f"✓ Option sélectionnée (JS/select) : {option_text}. source: input_dropdown.py")
                try:
                    driver._ui_overlay_opened = None
                except Exception:
                    pass
                return True

            # fallback Selenium Select
            _sel_el = s  # Playwright: use .select_option() and .evaluate() for options
            for opt in driver.evaluate("el => Array.from(el.options).map(o => ({value:o.value,text:o.text.trim()}))", _sel_el):
                ot = norm_txt(opt["text"])
                if target and (target == ot or target in ot):
                    driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", s)
                    time.sleep(0.1)
                    try:
                        _sel_el.select_option(label=opt["text"])
                    except Exception:
                        if opt.get("value"):
                            _sel_el.select_option(value=opt.get_attribute("value"))
                        else:
                            opt.click()

                    driver.execute_script("""
                      const s = arguments[0];
                      try { s.dispatchEvent(new Event('input', {bubbles:true})); } catch(e){}
                      try { s.dispatchEvent(new Event('change',{bubbles:true})); } catch(e){}
                      try { s.dispatchEvent(new Event('blur',  {bubbles:true})); } catch(e){}
                    """, s)
                    print(f"✓ Option sélectionnée (natif) : {opt['text']}. source: input_dropdown.py")
                    try:
                        driver._ui_overlay_opened = None
                    except:
                        pass
                    return True
            # match value
            for opt in driver.evaluate("el => Array.from(el.options).map(o => ({value:o.value,text:o.text.trim()}))", _sel_el):
                ov = norm_txt(opt.get_attribute("value") or "")
                if target and target == ov:
                    driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", s)
                    time.sleep(0.1)
                    _sel_el.select_option(value=opt.get_attribute("value"))
                    print(f"✓ Option sélectionnée (natif/value) : {opt.get_attribute('value')}. source: input_dropdown.py")
                    return True
        except Exception:
            continue

    # B) Dropdown custom : suppose menu déjà ouvert
    candidates = []
    candidates += driver.query_selector_all("xpath=//li[normalize-space(.)!='']")
    candidates += driver.query_selector_all("[role='option']")
    candidates += driver.query_selector_all(
        "xpath=//*[contains(@class,'option') and normalize-space(text())!='']"
    )
    for c in candidates:
        try:
            txt = norm_txt(c.get_attribute("innerText") or c.text)
            if not txt:
                continue
            if target and (target == txt or target in txt):
                driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", c)
                time.sleep(0.1)
                c.click()
                time.sleep(0.2)
                print(f"✓ Option sélectionnée (custom) : {option_text}. source: input_dropdown.py")
                try:
                    driver._ui_overlay_opened = None
                except:
                    pass
                return True
        except Exception:
            continue

    print(f"❌ Option '{option_text}' introuvable dans dropdown. source: input_dropdown.py")
    return False


# =============================================================================
# SÉLECTION NATIVE PAR TARGET_ID (registry) — bypass select_option_with_hint()
# =============================================================================
#
# Guard DOM strict : appelée uniquement si target_payload.context.tag == "select"
# (résolution par xpath/id du registry, cf. Survey/dom_analyzer.py register_target()).
#
# Corrige : select_option_with_hint() (fallback custom, section "CUSTOM: ouvrir puis
# sélectionner") appelle open_dropdown_generic(), qui lit `el.tag_name` — attribut
# Selenium (WebElement), inexistant sur ElementHandle Playwright. Cet AttributeError
# n'est catché nulle part sur ce chemin et remonte jusqu'à execute_action()/_try(),
# qui ne catch pas non plus -> l'exception atteint le plan d'exécution des actions.
# Cette fonction résout et sélectionne le <select> directement via l'API Playwright
# (query_selector/evaluate/select_option), sans jamais appeler open_dropdown_generic()
# ni select_option_with_hint().
def select_native_option_by_target(
    driver,
    xpath: str,
    el_id: str,
    option_text: str,
    alt_xpaths=None,
    el_name: str = "",
) -> bool:
    """
    Sélectionne option_text dans le <select> natif résolu via xpath/id/alt_xpaths/name
    du registry (target_payload d'un bloc itype=dropdown, context.tag=="select").

    Résolution en 4 étapes (chacune vérifie tagName=="select" avant de servir) :
    1) xpath principal du registry
    2) #id du registry
    3) alt_xpaths du registry (ex: //select[@name='...'])
    4) dernier recours: tous les <select> visibles de la page, filtré par la
       présence d'une option correspondant à option_text — nécessaire quand le
       xpath absolu (position DOM) et l'id sont devenus stales (re-render Wicket/AJAX
       entre l'extraction et l'exécution de l'action).
    """
    def _is_select(cand) -> bool:
        try:
            return (cand.evaluate("e => e.tagName.toLowerCase()") or "") == "select"
        except Exception:
            return False

    el = None
    if xpath:
        try:
            cand = driver.query_selector(f"xpath={xpath}")
            if cand is not None and _is_select(cand):
                el = cand
        except Exception:
            pass

    if el is None and el_id:
        try:
            cand = driver.query_selector(f"#{el_id}")
            if cand is not None and _is_select(cand):
                el = cand
        except Exception:
            pass

    if el is None:
        for ax in (alt_xpaths or []):
            if not ax:
                continue
            try:
                cand = driver.query_selector(f"xpath={ax}")
                if cand is not None and _is_select(cand):
                    el = cand
                    break
            except Exception:
                continue

    target = norm_txt(option_text)
    if not target:
        log_debug("dropdown-native", "select_native_option_by_target: option_text vide")
        return False

    if el is None:
        # Dernier recours: scanner tous les <select> visibles et matcher par option.
        # Fait en UN SEUL aller-retour navigateur (evaluate_handle côté JS) au lieu
        # d'un query_selector_all() + is_visible()/evaluate() par élément : sur une
        # page avec de nombreux <select> (ex. champs techniques Wicket cachés), le
        # coût par-élément (2 aller-retours Playwright chacun) faisait dériver cette
        # résolution à plusieurs dizaines de secondes. Le budget (300 selects, cap
        # dur côté JS) protège contre un DOM pathologique sans coût réseau ajouté.
        try:
            handle = driver.evaluate_handle(
                """(tgt) => {
                    const MAX = 300;
                    const norm = (s) => (s || '').normalize('NFKD')
                        .replace(/[\\u0300-\\u036f]/g, '')
                        .trim().toLowerCase();
                    const t = norm(tgt);
                    if (!t) return null;
                    const selects = Array.from(document.querySelectorAll('select')).slice(0, MAX);
                    for (const s of selects) {
                        const r = s.getBoundingClientRect();
                        if (r.width <= 0 || r.height <= 0) continue;
                        const opts = s.options;
                        for (let i = 0; i < opts.length; i++) {
                            if (norm(opts[i].text) === t) return s;
                        }
                    }
                    return null;
                }""",
                option_text,
            )
            cand = handle.as_element() if handle else None
            if cand is not None:
                el = cand
        except Exception:
            el = None

    if el is None:
        log_debug(
            "dropdown-native",
            f"select_native_option_by_target: <select> introuvable (id={el_id!r} name={el_name!r})",
        )
        return False

    try:
        opts = driver.evaluate(
            "el => Array.from(el.options).map(o => ({value: o.value, text: o.text.trim()}))",
            el,
        ) or []
    except Exception:
        opts = []

    matched = None
    for o in opts:
        ot = norm_txt(o.get("text") or "")
        ov = norm_txt(o.get("value") or "")
        if target == ot or target == ov:
            matched = o
            break
    if matched is None:
        for o in opts:
            ot = norm_txt(o.get("text") or "")
            if ot and target in ot:
                matched = o
                break
    if matched is None:
        log_debug(
            "dropdown-native",
            f"select_native_option_by_target: option {option_text!r} absente des <option> (n={len(opts)})",
        )
        return False

    try:
        driver.evaluate("(e) => e.scrollIntoView({block:'center'})", el)
    except Exception:
        pass

    # Assignation JS directe (sel.value + dispatch input/change), PAS el.select_option().
    # select_option() applique les vérifications d'actionability Playwright, dont la
    # visibilité — or ce <select> peut être rendu volontairement invisible au profit
    # d'un widget de substitution visuel (ex. bootstrap-select : classe bs-select-hidden,
    # menu <ul class="dropdown-menu inner"> cliquable en superposition). select_option()
    # échoue alors proprement (timeout catché, pas d'exception qui remonte) sans jamais
    # appliquer la valeur. L'assignation JS fonctionne indépendamment de la visibilité et
    # déclenche le refresh du widget (jQuery selectpicker) quand il est présent, même
    # pattern déjà utilisé pour ce cas dans Survey/action_dispatcher.py (_apply_by_target_id,
    # branche kind="single"/dropdown).
    try:
        driver.evaluate(
            """(args) => {
                const [sel, val] = args;
                sel.value = val;
                try { sel.dispatchEvent(new Event('input', {bubbles:true})); } catch(e) {}
                try { sel.dispatchEvent(new Event('change', {bubbles:true})); } catch(e) {}
                try {
                    if (window.jQuery && window.jQuery(sel).selectpicker) {
                        window.jQuery(sel).selectpicker('refresh');
                    }
                } catch(e) {}
            }""",
            [el, matched.get("value")],
        )
    except Exception:
        return False

    try:
        applied_txt = norm_txt(
            driver.evaluate("e => e.options[e.selectedIndex]?.text || ''", el) or ""
        )
    except Exception:
        applied_txt = ""

    if applied_txt != norm_txt(matched.get("text") or ""):
        log_debug(
            "dropdown-native",
            f"select_native_option_by_target: valeur non confirmée après assignation "
            f"(attendu={matched.get('text')!r} lu={applied_txt!r})",
        )
        return False

    print(f"✓ Option sélectionnée (natif/target_id) : {matched['text']}. source: input_dropdown.py")
    try:
        driver._ui_overlay_opened = None
    except Exception:
        pass
    return True


def select_option_with_hint(
    driver, 
    option_text: str, 
    field_hint: str | None = None, 
    context_hint: str | None = None
) -> bool:
    """
    Sélectionne option_text dans le dropdown le plus pertinent en un seul enchaînement.
    - <select> natif: sélection directe (pas d'ouverture).
    - dropdown custom: ouvre puis sélectionne tout de suite.
    - 2 tentatives max si le menu se referme.
    
    Args:
        driver: WebDriver
        option_text: texte de l'option à sélectionner
        field_hint: hint pour identifier le dropdown
        context_hint: contexte de question optionnel
    
    Returns:
        True si sélection réussie
    """
    target = norm_txt(option_text)

    def _pick_matching_option(options, target_text: str):
        """
        Retourne la meilleure option selon une stratégie simple et robuste:
        1) match exact sur texte normalisé ou value normalisée,
        2) sinon match partiel uniquement (target inclus dans texte option).
        """
        if not target_text:
            return None

        partial_candidate = None
        for opt in options:
            try:
                ot = norm_txt(opt["text"])
                ov = norm_txt(opt.get_attribute("value") or "")
            except Exception:
                continue

            if target_text == ot or target_text == ov:
                return opt

            if partial_candidate is None and ot and target_text in ot:
                partial_candidate = opt

        return partial_candidate

    # Disambiguation robuste mois/année
    _MONTHS_FR = {
        "janvier", "février", "fevrier", "mars", "avril", "mai", "juin",
        "juillet", "août", "aout", "septembre", "octobre", "novembre", "décembre", "decembre",
    }

    def _forced_hint_from_value(val_norm: str) -> str | None:
        if not val_norm:
            return None
        if val_norm in _MONTHS_FR:
            return "mois"
        if re.fullmatch(r"\d{4}", val_norm):
            try:
                y = int(val_norm)
                if 1900 <= y <= 2100:
                    return "année"
            except Exception:
                pass
        return None

    forced_hint = _forced_hint_from_value(target)
    effective_hint = forced_hint or field_hint or option_text

    def _select_bootstrap_option(anchor_el, wanted_text: str) -> bool:
        """Sélection stricte d'une option bootstrap-select via l'ancre <a> de menu ouvert."""
        try:
            aid = (anchor_el.get_attribute("id") or "").strip()
        except Exception:
            aid = ""
        if not aid:
            return False

        try:
            menu_anchors = driver.query_selector_all(
                "xpath=//button[@data-id=" + repr(aid) + "]"
                "/following-sibling::div[contains(@class,'dropdown-menu') and contains(@class,'open')]"
                "//ul[contains(@class,'dropdown-menu') and contains(@class,'inner')]"
                "//li[not(contains(@class,'disabled'))]/a"
            )
        except Exception:
            menu_anchors = []

        for a in menu_anchors:
            try:
                txt = norm_txt(a.get_attribute("innerText") or a.text)
                if not txt:
                    continue
                if wanted_text == txt or wanted_text in txt:
                    driver.evaluate("(el) => el.scrollIntoView({block:'center'})", a)
                    a.click()
                    print(f"✓ Option sélectionnée (bootstrap-select) : {option_text}. source: input_dropdown.py")
                    try:
                        driver._ui_overlay_opened = None
                    except Exception:
                        pass
                    return True
            except Exception:
                continue

        return False

    # --- NATIF <select>: sélection directe (sans ouvrir)
    selects = driver.query_selector_all("select")
    if selects:
        s = best_dropdown_for_hint(driver, effective_hint, context_hint=context_hint)
        try_selects = []
        if s is not None:
            try_selects.append(s)
        try_selects += [el for el in selects if (s is None or getattr(el, "_id", id(el)) != getattr(s, "_id", id(s)))]
        
        for sel_el in try_selects:
            try:
                # GfK mrIWeb: .mrDropdown in .platform_clone — Selenium Select won't
                # trigger Angular $digest; must click .cb_el then .cb_item_row.
                sel_classes = (sel_el.get_attribute("class") or "").lower()
                if "mrdropdown" in sel_classes:
                    # Locate .combo_master: primary — via .acc_ct ancestor; fallback — preceding-sibling of .platform_clone
                    combo_masters = sel_el.find_elements(
                        "xpath",
                        "ancestor::div[contains(concat(' ',normalize-space(@class),' '),' acc_ct ')][1]"
                        "/div[contains(concat(' ',normalize-space(@class),' '),' combo_master ')]",
                    )
                    log_debug("gfk-combo", f"combo_masters via acc_ct: {len(combo_masters)}")
                    if not combo_masters:
                        combo_masters = sel_el.find_elements(
                            "xpath",
                            "ancestor::div[contains(concat(' ',normalize-space(@class),' '),' platform_clone ')][1]"
                            "/preceding-sibling::div[contains(concat(' ',normalize-space(@class),' '),' combo_master ')][1]",
                        )
                        log_debug("gfk-combo", f"combo_masters via preceding-sibling: {len(combo_masters)}")
                    if combo_masters:
                        cm = combo_masters[0]
                        cb_els = cm.query_selector_all(".cb_el")
                        if cb_els:
                            driver.evaluate("(el) => el.click()", cb_els[0])
                            # Wait for .b_l_ct (Angular ng-show) to become visible
                            deadline = time.time() + 2.0
                            cb_list = None
                            while time.time() < deadline:
                                b_l_cts = cm.query_selector_all(".b_l_ct")
                                if b_l_cts and b_l_cts[0].is_visible():
                                    lists = b_l_cts[0].query_selector_all(".cb_list")
                                    if lists:
                                        cb_list = lists[0]
                                        break
                                time.sleep(0.05)
                            # Fallback: try button.combo_button if .b_l_ct still hidden
                            if cb_list is None:
                                btns = cb_els[0].query_selector_all("button.combo_button")
                                if btns:
                                    driver.evaluate("(el) => el.click()", btns[0])
                                    deadline2 = time.time() + 2.0
                                    while time.time() < deadline2:
                                        b_l_cts = cm.query_selector_all(".b_l_ct")
                                        if b_l_cts and b_l_cts[0].is_visible():
                                            lists = b_l_cts[0].query_selector_all(".cb_list")
                                            if lists:
                                                cb_list = lists[0]
                                                break
                                        time.sleep(0.05)
                            if cb_list:
                                for row in cb_list.query_selector_all(".cb_item_row"):
                                    try:
                                        items = row.query_selector_all(".cb_item")
                                        if not items:
                                            continue
                                        txt = norm_txt(items[0].get_attribute("innerText") or items[0].text)
                                        if target == txt or (target and target in txt):
                                            driver.evaluate("(el) => el.click()", row)
                                            print(f"✓ Option sélectionnée (gfk-combo) : {option_text}. source: input_dropdown.py")
                                            try:
                                                driver._ui_overlay_opened = None
                                            except Exception:
                                                pass
                                            return True
                                    except Exception:
                                        continue
                            log_debug("gfk-combo", f"cb_list not visible or option '{option_text}' not found")
                    # mrDropdown detected but selection failed — don't fall through to Selenium Select
                    continue

                _sel_el = sel_el  # Playwright: use .select_option() and .evaluate() for options
                opt = _pick_matching_option(driver.evaluate("el => Array.from(el.options).map(o => ({value:o.value,text:o.text.trim()}))", _sel_el), target)
                if not opt:
                    continue

                driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", sel_el)
                try:
                    _sel_el.select_option(label=opt["text"])
                except Exception:
                    if opt.get("value"):
                        _sel_el.select_option(value=opt.get("value"))
                    else:
                        opt.click()

                try:
                    sel_el.evaluate("(s) => { ['input','change','blur','focusout'].forEach(t => "
                                    "{ try{s.dispatchEvent(new Event(t,{bubbles:true}))}catch(e){} })")
                except Exception:
                    pass

                print(f"✓ Option sélectionnée (natif) : {opt['text']}. source: input_dropdown.py")
                try:
                    driver._ui_overlay_opened = None
                except Exception:
                    pass
                return True
            except Exception:
                continue

    # --- CUSTOM: ouvrir puis sélectionner (avec retries)
    for attempt in range(2):
        opened = open_dropdown_generic(driver, hint=effective_hint, context_hint=context_hint)

        if opened:
            try:
                ov = getattr(driver, "_ui_overlay_opened", None) or {}
                anchor = ov.get("anchor")
                if anchor is not None:
                    anchor_cls = norm_txt(anchor.get_attribute("class") or "")
                    if anchor.tag_name.lower() == "select" and ("bs-select-hidden" in anchor_cls or "bootstrap-select" in anchor_cls):
                        if _select_bootstrap_option(anchor, target):
                            return True
            except Exception:
                pass
        
        # Si aucune option à appliquer et champ déjà rempli, skip
        if not option_text:
            try:
                ov = getattr(driver, "_ui_overlay_opened", None)
                if ov and ov.get("type") == "dropdown" and ov.get("filled") is True:
                    print("✓ Dropdown déjà rempli, on ne modifie pas. source: input_dropdown.py")
                    try:
                        driver._ui_overlay_opened = None
                    except Exception:
                        pass
                    return True
            except Exception:
                pass

        # Rechercher des options visibles
        deadline = time.time() + 1.0
        while time.time() < deadline:
            candidates = []
            candidates += driver.query_selector_all("[role='option']")
            candidates += driver.query_selector_all("xpath=//li[normalize-space(.)!='']")
            candidates += driver.query_selector_all(
                "xpath=//*[contains(@class,'option') and normalize-space(text())!='']"
            )

            for c in candidates:
                try:
                    if not c.is_visible():
                        continue
                    txt = norm_txt(c.get_attribute("innerText") or c.text)
                    if target and (target == txt or target in txt):
                        driver.evaluate("(el) => el.scrollIntoView({block:\'center\'})", c)
                        c.click()
                        print(f"✓ Option sélectionnée (custom) : {option_text}. source: input_dropdown.py")
                        try:
                            driver._ui_overlay_opened = None
                        except Exception:
                            pass
                        return True
                except Exception:
                    continue
            time.sleep(0.05)

        print("↻ Menu refermé / option non visible, nouvelle tentative… source: input_dropdown.py")

    print(f"❌ Option '{option_text}' introuvable dans dropdown. source: input_dropdown.py")
    return False
